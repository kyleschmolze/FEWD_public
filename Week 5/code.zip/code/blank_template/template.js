var x = parseInt(prompt("Please giveth thy number:"));

while(true) {
	x = parseInt(prompt("Invalid! Please giveth thy number:"));
}

alert("Got a number: " + x);